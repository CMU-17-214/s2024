package edu.cmu.cs.cs214.lect01.trees;

/** Defines constants used by several classes */
public class Constants {
	public static final int MAX_X = 100;
	public static final int MAX_Y = 100;
	public static final int INITIAL_AGE = 1;
	public static final double PROB_NATURAL_DEATH = 0.01;
	public static final double PROB_SEEDLING = 0.001;
	public static final int SEEDLING_DISTANCE = 5;
}
