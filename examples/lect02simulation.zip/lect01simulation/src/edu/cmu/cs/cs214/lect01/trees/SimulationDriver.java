package edu.cmu.cs.cs214.lect01.trees;

/** A container for the main function of the simulation program */
public class SimulationDriver {
	private static final int NUM_TREES = (int) (Constants.MAX_X * Constants.MAX_Y * 0.8);
	private static final int NUM_INFESTED = 10;
	private static final int MAX_AGE = 100;

	/** Sets up the simulation and runs it */
	public static void main(String[] args) {
		Simulation s = new Simulation();
		for (int i = 0; i < NUM_TREES; ++i)
			s.add(new LodgepolePine((i % MAX_AGE) + 1, s.getEmptySpot()));
		for (int i = 0; i < NUM_INFESTED; ++i)
			s.add(new InfectedPine((i % MAX_AGE) + 1, s.getEmptySpot()));
		s.simulate();
	}
}
